interface Functions {
    public void eod(int x, int y);

    public int mul(int x, int y);

    public void div(int x, int y);

    public int sum(int x, int y);

    public void sub(int x, int y);
}

